import React from 'react'
import Form from './Component/Form'
const App = () => {
  return (
    <div>
      <Form />
    </div>
  )
}

export default App